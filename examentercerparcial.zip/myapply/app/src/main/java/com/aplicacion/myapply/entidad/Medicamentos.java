package com.aplicacion.myapply.entidad;

import android.media.Image;

import java.sql.Blob;

public class Medicamentos {
    /* tablas */
    public static final String tablamedicamento = "medicina";
    /* Campos */
    public static final String id_medicamento = "id_medicamento";
    public static final String descripcion = "descripcion";
    public static final String tiempo = "tiempo";
    public static final String cantidad = "cantidad";
    public static final String periocidad = "periocidad";
    public static final String imagen = "imagen";

    /* tablas - CREATE , DROP */
    public static final String CreateTablePersonas = "CREATE TABLE " + tablamedicamento+"(" + id_medicamento + " INTEGER PRIMARY KEY AUTOINCREMENT, "+descripcion+" TEXT, "+tiempo+" TEXT,"+periosidad+" INTEGER)";
    // public static final String CreateTablePersonas1 =  "CREATE TABLE " +tablapersonas+ " ("+NOMBRE+ " TEXT, "+EDAD+" INTEGER, "+CIUDAD+" TEXT, "+CODIGOPOSTAL+" INTEGER, "+SEXO+" TEXT, "+PAIS+" TEXT)";
    public static final String DropTablePersonas = "DROP TABLE IF EXISTS personas";




    /* Creacion del nombre de la base de datos */
    public static final String NameDataBase = "DBExamen";
}

