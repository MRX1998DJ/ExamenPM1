package com.aplicacion.myapply;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.location.Location;
import android.location.LocationManager;
import android.media.Image;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.aplicacion.myapply.db.SQLiteConexion;
import com.aplicacion.myapply.entidad.Medicamentos;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainActivity extends AppCompatActivity {


    static final int MY_PERMISSIONS_REQUEST_CAMARA=1;
    private Uri photoURI;
    Button btSalvados, btnFotos, btnSalvar;

    EditText descripcion, cantidad, tiempo, periocidad;
    ImageView imagen;
    Bitmap imageBitmap;

    static final int REQUEST_IMAGE_CAPTURE = 1;
    static final int PETICION_ACCESO_CAM = 100;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        descripcion=(EditText)findViewById(R.id.editdes);
        cantidad=(EditText)findViewById(R.id.edicant);
        tiempo=(EditText) findViewById(R.id.Spitiem);
        periocidad=(EditText)findViewById(R.id.ediperiodo);
        imagen=(ImageView)findViewById(R.id.imageView);
        btnFotos=(Button) findViewById(R.id.btnFotos);
        btnFotos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                permisos();
            }
        });
        btnSalvar=(Button)findViewById(R.id.btSalvar);
        btnSalvar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AgregarMedicamentos();
            }
        });


    }

    private void AgregarMedicamentos() {
        SQLiteConexion conexion= new SQLiteConexion(this, Medicamentos.NameDataBase, null, 1);
        SQLiteDatabase bd= conexion.getWritableDatabase();

        ContentValues valores= new ContentValues();
        valores.put(Medicamentos.descripcion, descripcion.getText().toString());
        valores.put(Medicamentos.cantidad, cantidad.getText().toString());
        valores.put(Medicamentos.tiempo, tiempo.getText().toString());
        valores.put(Medicamentos.periocidad, periocidad.getText().toString());
        valores.put(Medicamentos.imagen, String.valueOf(imageBitmap));

        Long resultado= bd.insert(Medicamentos.tablamedicamento, Medicamentos.id_medicamento, valores);
        Toast.makeText(getApplicationContext(), "Ingresado" + resultado.toString(), Toast.LENGTH_LONG).show();
        bd.close();

        limpiar();
    }

    private void limpiar() {
        descripcion.setText("");
        cantidad.setText("");
        tiempo.setText("");
        periocidad.setText("");
    }

    private void permisos()
    {
        if(ContextCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.CAMERA) !=
                PackageManager.PERMISSION_GRANTED)
        {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, PETICION_ACCESO_CAM);
        }
        else
        {
            tomarfoto();
        }
    }

    private void tomarfoto() {
        Intent intent= new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if(intent.resolveActivity(getPackageManager()) != null)
        {
            startActivityForResult(intent, REQUEST_IMAGE_CAPTURE);
        }
    }

    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {

        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if(requestCode == PETICION_ACCESO_CAM)
        {
            if(grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED)
            {
                tomarfoto();
            }
        }
        else
        {
            Toast.makeText(getApplicationContext(), "Se necesitan permisos de acceso", Toast.LENGTH_LONG).show();
        }
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK) {
            Bundle extras = data.getExtras();
            imageBitmap = (Bitmap) extras.get("data");
            imagen.setImageBitmap(imageBitmap);
        }
    }}