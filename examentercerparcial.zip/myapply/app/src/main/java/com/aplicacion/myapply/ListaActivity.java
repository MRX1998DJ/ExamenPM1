package com.aplicacion.myapply;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.aplicacion.myapply.db.SQLiteConexion;
import com.aplicacion.myapply.entidad.Medicamentos;


import java.util.ArrayList;

public class ListaActivity extends AppCompatActivity {

    EditText id, nombre, numero, nota,pais;
    SQLiteConexion conexion;
    ListView listaPersona;
    String num, nom, not;
    ArrayAdapter<String> adapter;
    ArrayList<Personas> lista =new ArrayList<Personas>();;
    ArrayList<String> ArregloPersona;
    String posicion, po;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista);


        conexion= new SQLiteConexion(this, Medicamentos.NameDataBase, null, 1);
        listaPersona=(ListView)findViewById(R.id.listaPersonas);

        ObtenerLista();
        ArrayAdapter adp= new ArrayAdapter(getApplicationContext(), android.R.layout.simple_list_item_1, ArregloPersona);
        listaPersona.setAdapter(adp);


       listaPersona.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override

            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String info=" ID " + lista.get(position).getId()+"\n";
                info+= "Nombre : " +lista.get(position).getNombre();
                posicion=lista.get(position).getId()+"";
                nom=lista.get(position).getNombre ()+"";
                num=lista.get(position).getNumero ()+"";
                not=lista.get(position).getNota ()+"";
                String listChoice=(listaPersona.getItemAtPosition(position).toString());
                Intent intent=new Intent(getApplicationContext(), Modificar_Activity.class);
                intent.putExtra("hola", num);
                startActivity(intent);
                Toast.makeText(getApplicationContext(),listChoice, Toast.LENGTH_LONG).show();
                openDialog();



            }

        });

        Button btnconsulta=(Button)findViewById(R.id.btnBuscar);
        btnconsulta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Buscar();
            }
        });

        Button btna=(Button)findViewById(R.id.btnAtras);
        btna.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
            }
        });

        Button btneliminar=(Button)findViewById ( R.id.btnLEliminar );
        btneliminar.setOnClickListener ( new View.OnClickListener () {
            @Override
            public void onClick(View v) {
               // Toast.makeText ( getApplicationContext (),posicion,Toast.LENGTH_LONG).show ();
                Eliminar ();


            }
        } );


        Button actualizar=(Button)findViewById ( R.id.btnLModificar );
        actualizar.setOnClickListener ( new View.OnClickListener () {
            @Override
            public void onClick(View v) {
        //        Toast.makeText ( getApplicationContext (),posicion,Toast.LENGTH_LONG).show ();
                Intent intent= new Intent (getApplicationContext(), ActivityActualizar.class);
                intent.putExtra ( "nombre" ,nom);
                intent.putExtra ( "numero",num );
                intent.putExtra ( "nota",not );
                intent.putExtra ( "id",posicion );
                startActivity (intent);
            }
        } );

       /* Button btnM =(Button)findViewById(R.id.btnLModificar);
        btnM.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent= new Intent(getApplicationContext(), Modificar_Activity.class);
                intent.putExtra("hola", Transacciones.id);
                intent.putExtra("mundo", nombre.getText());
                intent.putExtra("pro", numero.getText());
                startActivity(intent);
            }
        });*/

        Button btnllamar=(Button)findViewById(R.id.btnLlamada);
        btnllamar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent= new Intent(getApplicationContext(), Modificar_Activity.class);
                intent.putExtra("hola", nom);
                intent.putExtra("mundo", num);
                intent.putExtra("pro", not);
                startActivity(intent);
                openDialog();

            }
        });

    }

    private void openDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(ListaActivity.this);
        builder.setTitle("Llamar Contacto");
        builder.setMessage("Desea Llamar A:");

       // builder.setPositiveButton("Aceptar", null);
        builder.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Intent intent= new Intent(getApplicationContext(), Modificar_Activity.class);
                startActivity(intent);

            }
        });

      //  builder.setNegativeButton("Cancelar", null);
        builder.setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        AlertDialog dialog = builder.create();
        dialog.show();
    }


    private void ObtenerLista() {

        SQLiteDatabase db= conexion.getReadableDatabase();

        Personas listPersonas=null;

        Cursor cursor= db.rawQuery("SELECT * FROM "+Transacciones.tablapersonas, null);

        while (cursor.moveToNext())
        {
            listPersonas= new Personas();
            listPersonas.setId(cursor.getInt(0));
            listPersonas.setNombre(cursor.getString(1));

            listPersonas.setNumero(cursor.getInt(3));
            listPersonas.setNota(cursor.getString(4));
            listPersonas.setPais ( cursor.getString (2) );


            lista.add(listPersonas);
        }
        LLenarLista();
    }

    private void LLenarLista()
    {
        ArregloPersona=new ArrayList<String>();
        for (int i=0; i < lista.size(); i++)
        {
            ArregloPersona.add(lista.get(i).getId() + " | "
                            +lista.get(i).getNumero()+"|"
                    +lista.get(i).getNombre()+ " | "
                    +lista.get(i).getPais ());
        }
    }

    private void Buscar() {
        SQLiteDatabase bd= conexion.getWritableDatabase();
        String [] parames= {id.getText().toString()};
        String [] fields= {Medicamentos.descripcion, Medicamentos.cantidad,
                Medicamentos.periocidad};

        String condicion= Medicamentos.id_medicamento + "=?";

        try {

            Cursor cdata = bd.query(Medicamentos.tablamedicamento, fields,
                    condicion, parames, null, null, null);
            cdata.moveToFirst();

            nombre.setText(cdata.getString(0));
            numero.setText(cdata.getString(1));
            nota.setText(cdata.getString(2));
            Toast.makeText(getApplicationContext(), "Consulta Exitosa", Toast.LENGTH_LONG).show();

        }catch (Exception e)
        {
            limpiar();
            Toast.makeText(getApplicationContext(), "Consulta No Encontrados", Toast.LENGTH_LONG).show();

        }

    }
    private void limpiar() {
        nombre.setText("");
        numero.setText("");
        nota.setText("");
    }

    private void Eliminar()
    {
        SQLiteDatabase db= conexion.getWritableDatabase ();
        String[] params ={posicion};
        String wherecond = Medicamentos.id_medicamento+"=?";
        db.delete ( Medicamentos.tablamedicamento,wherecond,params );
        Toast.makeText ( getApplicationContext (),"Dato eliminado",Toast.LENGTH_LONG ).show ();

        //LLenarLista ();

    }
  //  posicion=lista.get(position).getId()+"\n";




}